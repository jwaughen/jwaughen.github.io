$(function() {
    //Adding logo to all HTML pages
    $('.logo').html("<a href=\"index.html\"><img src=\"images/Sweet Escapes Logo.png\"></a>");

    //Adding footer to all HTML pages
    $('footer').html("<p>Admin <a href=\"login.html\">Log In</a></p></br>");

});





